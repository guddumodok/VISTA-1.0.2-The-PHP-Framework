<?php
define("vista","guddu modok");
include(".vista");
$vista=new vista();
$vista->sthead();
$vista->jquery();
$vista->css();
$vista->ehead();




?>